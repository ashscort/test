package com.cy.service;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

public interface IFileDownloadService {
   String fileDownload(HttpServletResponse response,String filename) throws IOException;
}
