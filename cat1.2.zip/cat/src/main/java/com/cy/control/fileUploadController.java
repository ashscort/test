package com.cy.control;

//import com.cy.config.UploadConfig;
import com.cy.config.UploadConfig;
import com.cy.entity.Fileinfo;
import com.cy.service.impl.FileinfoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class fileUploadController {

    private  Map<String,Object> res = new HashMap<>();
    private Fileinfo fileinfo;
    @Autowired
    private UploadConfig uploadConfig;

    @Autowired
    private FileinfoServiceImpl fileInfoService;

    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public  String FileUpload(HttpServletRequest request, MultipartFile file){

        System.out.println(file);
        String fileName = "";
        if (!file.isEmpty()) {
        //获取文件的后缀
            String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));

            //定义新文件的名字
            fileName = System.currentTimeMillis() + suffix;

        //定义文件存储的最终路径
        String savePath = uploadConfig.getFilePath() + fileName;
//        String savePath = "G:/test" + fileName;
        File dest = new File(savePath);
        if(!dest.getParentFile().exists()) {
            dest.getParentFile().mkdirs();
        }
        try {
            file.transferTo(dest);//保存文件
        } catch (IOException e) {
            e.printStackTrace();
            res.put("error","文件上传失败");
            return "redirect:/upload.html";
        }
    } else {
            res.put("error","文件上传失败");
            return "redirect:/upload.html";
    }

    //将上传成功后的文件路径返回到前端

//    String fileVisitPath = uploadConfig.getUrlPath() + "/public/film/" + fileName; //为了在富文本编辑器中使用
    String filePath = fileName;//存表中
        System.out.println(request.getParameter("description"));
        String description = request.getParameter("description");
//    String description = "aaaaa";
     res = fileInfoService.SaveFileInfo(fileName,description);
        res.put("i","success");
        return "redirect:/upload.html";
    }
}
