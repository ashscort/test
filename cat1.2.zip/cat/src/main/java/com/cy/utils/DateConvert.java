package com.cy.utils;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class DateConvert {
    public String DateConvertor(Date date)
    {
        String result;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy--MM--dd");
        result = sdf.format(date);

        return result ;
    }
}
