package com.cy.service;

import com.cy.entity.Fileinfo;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface IFileDownloadService {
   String fileDownload(HttpServletResponse response,String filename) throws IOException;

   List<Fileinfo> selectAll();
}
