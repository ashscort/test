package com.cy.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
//import com.cy.config.UploadConfig;
import com.cy.entity.Fileinfo;
import com.cy.mapper.FileinfoMapper;
import com.cy.service.IFileinfoService;

import com.fasterxml.jackson.databind.node.ArrayNode;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jobob
 * @since 2020-03-13
 */
@Service
public class FileinfoServiceImpl extends ServiceImpl<FileinfoMapper, Fileinfo> implements IFileinfoService {


    Map<String,Object> map = new HashMap();

    Fileinfo fileinfo = new Fileinfo();
    @Autowired
    private FileinfoMapper fileinfoMapper;


    public  Map<String,Object> SaveFileInfo(String filename,String description) {
        System.out.println(filename+description);
        if(fileinfo != null)
        {
            fileinfo.setId(0);
            fileinfo.setDate(LocalDateTime.now());
            fileinfo.setDelFlag("0");
            fileinfo.setFilename(filename);
            fileinfo.setDescription(description);
            fileinfoMapper.insert(fileinfo);

            map.put("massage","success");
        }
        return map;

    }


}
