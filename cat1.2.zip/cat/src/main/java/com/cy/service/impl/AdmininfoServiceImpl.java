package com.cy.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cy.entity.Admininfo;
import com.cy.mapper.AdmininfoMapper;
import com.cy.service.IFileinfoService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jobob
 * @since 2020-03-13
 */
@Service
public class AdmininfoServiceImpl extends ServiceImpl<AdmininfoMapper, Admininfo>{

}
