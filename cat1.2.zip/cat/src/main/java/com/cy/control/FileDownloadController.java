package com.cy.control;


import com.cy.config.UploadConfig;
import com.cy.entity.Fileinfo;
import com.cy.service.impl.FileDownloadServiceImpl;
import com.cy.utils.DateConvert;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;


@Controller
public class FileDownloadController {
       /**设置请求头文件 目的 强制弹出下载框
        Content-Disposition: attachment; filename=filename.ex
        浏览器会使能识别的文件在浏览器内打开 所以应该设置文件为二进制数据流使文件顺利下载
        Content-Type: application/octet-stream**/
   @Autowired
   private FileDownloadServiceImpl fileDownloadService;

   @Autowired
   private UploadConfig uploadConfig;

//   private DateConvert dc;

    @GetMapping(value="/filedownload")
    public ResponseEntity<InputStreamResource> download(@RequestParam("filename") String filename) throws IOException {

        String path = uploadConfig.getFilePath()+filename;
        System.out.println(path);
        //以文件的绝对资源加载路径 所以path 应为系统的文件储存路径。
        FileSystemResource file = new FileSystemResource(path);
        System.out.println(file);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getFilename()));
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");
        return ResponseEntity
                .ok()
                .headers(headers)
                .contentLength(file.contentLength())
                .contentType(MediaType.parseMediaType("application/octet-stream"))
                .body(new InputStreamResource(file.getInputStream()));

    }

    @RequestMapping("/download.html")
    public String download()
    {
        return "download";
    }
    @RequestMapping(value = "/query")
    public void queryDate(HttpServletResponse response){
        Fileinfo fileinfo;
        try {
            List list;
            list = fileDownloadService.selectAll();
            //将数据转为json类型
            JSONArray data = JSONArray.fromObject(list);
            response.setCharacterEncoding("utf-8");
            PrintWriter pr = response.getWriter();
//            pr.write(data);
            String res = data.toString();
            pr.append(res);
            System.out.println(res);

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
