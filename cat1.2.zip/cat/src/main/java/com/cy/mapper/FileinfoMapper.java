package com.cy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cy.entity.Fileinfo;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 *  与数据库交互 仅查询功能 sql语句映射到mapper/back/FileinfoMapper.xml
 *  在FileinfoMapper.xml中编辑sql语句
 * </p>
 *
 * @author jobob
 * @since 2020-03-13
 */
@Repository
@Mapper
public interface FileinfoMapper extends BaseMapper<Fileinfo> {

}
