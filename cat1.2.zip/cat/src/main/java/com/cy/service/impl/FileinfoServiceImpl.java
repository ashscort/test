package com.cy.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.cy.entity.Fileinfo;
import com.cy.mapper.FileinfoMapper;
import com.cy.service.IFileinfoService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author jobob
 * @since 2020-03-13
 */
@Service
public class FileinfoServiceImpl extends ServiceImpl<FileinfoMapper, Fileinfo> implements IFileinfoService {


    Map<String,Object> map = new HashMap();

    Fileinfo fileinfo = new Fileinfo();
    @Autowired
    private FileinfoMapper fileinfoMapper;


    public  Map<String,Object> SaveFileInfo(String filename,String description) {
        System.out.println(filename+description);
        if(fileinfo != null)
        {
            fileinfo.setId(0);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd:HH:mm:ss");
            Date currentTime = new Date();
            fileinfo.setUptime(sdf.format(currentTime));

            fileinfo.setDelFlag("0");
            fileinfo.setFilename(filename);
            fileinfo.setDescription(description);
            fileinfoMapper.insert(fileinfo);

            map.put("massage","success");
        }
        return map;

    }


}
