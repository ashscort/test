package com.cy.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.thymeleaf.util.StringUtils;

import javax.print.DocFlavor;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.NotNull;
import java.util.Map;

@Controller
public class adminLogin {

    @PostMapping(value = "/usr/login")
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password,
                        Map<String, Object> map, HttpSession httpSession) {
        if (!StringUtils.isEmpty(username) && password.equals("123456")) {
            httpSession.setAttribute("loginUser", username);
            return "redirect:/main.html";
        } else {
            map.put("msg", "用户名或密码错误");
            return "login";
        }
    }

//    @RequestMapping("main")
//    public String toMain()
//    {
//        return "main";
//    }
//
//    @RequestMapping("login")
//    public String toLogin()
//    {
//        return "login";
//    }
}
