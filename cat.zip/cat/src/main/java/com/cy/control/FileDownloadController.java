package com.cy.control;


import com.cy.service.impl.FileDownloadServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class FileDownloadController {
       /**设置请求头文件 目的 强制弹出下载框
        Content-Disposition: attachment; filename=filename.ex
        浏览器会使能识别的文件在浏览器内打开 所以应该设置文件为二进制数据流使文件顺利下载
        Content-Type: application/octet-stream**/
    @RequestMapping(value = "/download")
    @ResponseBody
    public String fileDownload(HttpServletResponse response, @RequestParam("filename") String filename) throws IOException {
        response.setHeader("Content-Disposition","attachment; filename=filename.zip");
        response.setHeader("Content-Type","application/octet-stream");
        response.setContentType("application/octet-stream");
        if(!filename.isEmpty())
            new FileDownloadServiceImpl().fileDownload(response,filename);
        else{
            return "Download failed";
        }
        return "";

    }
}
