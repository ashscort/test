package com.cy.service.impl;

import com.cy.config.UploadConfig;
import com.cy.service.IFileDownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Map;

@Service
public class FileDownloadServiceImpl implements IFileDownloadService {
    @Autowired
    private UploadConfig uploadConfig;


    public String fileDownload(HttpServletResponse response, String filename) throws IOException {

//        String downloadFile = filename;
        String path = uploadConfig.getUrlPath() + filename;

        File file = new File(path);
        if (file.exists()) {
            byte[] buffer = new byte[1024];
            FileInputStream fileInputStream = null;
            BufferedInputStream bis = null;

            try {
                fileInputStream = new FileInputStream(file);
                bis = new BufferedInputStream(fileInputStream);
                int i = bis.read(buffer);
                OutputStream os = response.getOutputStream();
                while (i != -1) {
                    os.write(buffer, 0, i);
                    i = bis.read(buffer);

                }
                System.out.println("download successful");
                return "download success";

            } catch (Exception e) {
                e.printStackTrace();
                return "Failed Download";
            } finally {
                if (bis != null) {
                    bis.close();
                }
            }
        } else {
            return "failed download";
        }
    }
}
