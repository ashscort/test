package com.cy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cy.entity.Admininfo;
import com.cy.entity.Fileinfo;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jobob
 * @since 2020-03-13
 */
public interface IFileinfoService extends IService<Fileinfo> {

    /**
     * <p>
     *  服务类
     * </p>
     *
     * @author jobob
     * @since 2020-03-13
     **/
     Map<String,Object> SaveFileInfo(String filename,String description);

}
