package com.cy.config;

import com.cy.intercept.LoginHandlerInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//
@Configuration
public class mvcConfig implements WebMvcConfigurer {

    @Autowired
    private LoginHandlerInterceptor loginHandlerInterceptor;
    //视图映射 （uri路径） （本地路径）
    @Override
    public void addViewControllers(ViewControllerRegistry registry)
        {
            registry.addViewController("/").setViewName("login");
            registry.addViewController("/login").setViewName("login");
            registry.addViewController("/main.html").setViewName("dashboard");
            registry.addViewController("/index").setViewName("index");
//            registry.addViewController("/login").setViewName("login");
            registry.addViewController("/upload").setViewName("upload");
            registry.addViewController("/upload.html").setViewName("upload");
            registry.addViewController("/query").setViewName("download");
        }

    //视图拦截器

//    @Override
//    public void addInterceptors(InterceptorRegistry registry){
//        registry.addInterceptor(loginHandlerInterceptor).addPathPatterns("/**")
//                .excludePathPatterns("/", "/index", "/login", "/static/**","/upload");
//    }
//配置静态资源路径
    public void addResourceHandlers(ResourceHandlerRegistry registry)
    {
        registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
        registry.addResourceHandler("/public/**").addResourceLocations("file:/G:/Test/");
    }
}
