# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.5.RELEASE/maven-plugin/)
* [Spring Web](https://docs.spring.io/spring-boot/docs/2.2.5.RELEASE/reference/htmlsingle/#boot-features-developing-web-applications)
* [Spring Web Services](https://docs.spring.io/spring-boot/docs/2.2.5.RELEASE/reference/htmlsingle/#boot-features-webservices)
* [Thymeleaf](https://docs.spring.io/spring-boot/docs/2.2.5.RELEASE/reference/htmlsingle/#boot-features-spring-mvc-template-engines)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/bookmarks/)
* [Producing a SOAP web service](https://spring.io/guides/gs/producing-web-service/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)

#    type: com.alibaba.druid.pool.DruidDataSource
 #   data source other configuration
    #initialSize: 5
  #      minIdle: 5
#      maxActive: 20
#      maxWait: 60000
#      timeBetweenEvictionRunsMillis: 60000
#      minEvictableIdleTimeMillis: 300000
#      validationQuery: SELECT 1 FROM DUAL
#      testWhileIdle: true
#      testOnBorrow: false
#      testOnReturn: false
#      poolPreparedStatements: true
#      #   config detect counter filters，if remove monitor window cannot count sql;
  #and the properties use to the "firewall"
#      filters: stat,wall
#      maxPoolPreparedStatementPerConnectionSize: 20
#      useGlobalDataSourceStat: true
#      connectionProperties: druid.stat.mergeSql=true;druid.stat.slowSqlMillis=500
