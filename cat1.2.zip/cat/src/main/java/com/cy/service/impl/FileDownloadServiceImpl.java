package com.cy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cy.config.UploadConfig;
import com.cy.entity.Fileinfo;
import com.cy.mapper.FileinfoMapper;
import com.cy.service.IFileDownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;

@Service
public class FileDownloadServiceImpl implements IFileDownloadService {

    @Autowired
    private UploadConfig uploadConfig;

    @Autowired
    private FileinfoMapper fileinfoMapper;

    public String fileDownload(HttpServletResponse response, String filename) throws IOException {

//        String downloadFile = filename;
        String path = uploadConfig.getUrlPath() +"/public/file/"+filename;
        System.out.println(filename);

        File file = new File(path);
        if (file.exists()) {
            byte[] buffer = new byte[1024];
            FileInputStream fileInputStream = null;
            BufferedInputStream bis = null;

            try {
                fileInputStream = new FileInputStream(file);
                bis = new BufferedInputStream(fileInputStream);
                int i = bis.read(buffer);
                OutputStream os = response.getOutputStream();
                while (i != -1) {
                    os.write(buffer, 0, i);
                    i = bis.read(buffer);

                }
                System.out.println("download successful");
                return "download success";

            } catch (Exception e) {
                e.printStackTrace();
                return "Failed Download";
            } finally {
                if (bis != null) {
                    bis.close();
                }
            }
        } else {
            return "failed download";
        }
    }


    public List selectAll()
    {

        QueryWrapper<Fileinfo> queryWrapper = new QueryWrapper<>();
        System.out.println(fileinfoMapper.selectList(queryWrapper));
        return fileinfoMapper.selectList(queryWrapper);
    }
}
